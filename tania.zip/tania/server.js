const express = require('express');
const app = express();
const path = require('path');

// Define o diretório para os arquivos estáticos (como HTML, CSS, imagens)
app.use(express.static(path.join(__dirname, 'public')));
app.use('/templates', express.static(path.join(__dirname, 'templates')));

// Define as rotas
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/problema1', (req, res) => {
    res.sendFile(path.join(__dirname, 'templates', 'formulario.html'));
});

app.get('/problema2', (req, res) => {
    res.sendFile(path.join(__dirname, 'templates', 'jardim.html'));
});

app.get('/problema3', (req, res) => {
    res.sendFile(path.join(__dirname, 'templates', 'galinha.html'));
});

// Inicia o servidor na porta 3000
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
